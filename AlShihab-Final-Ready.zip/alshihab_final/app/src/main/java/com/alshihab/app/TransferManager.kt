package com.alshihab.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.content.SharedPreferences
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.max

private const val DISCOVERY_PORT = 45454
private const val TRANSFER_PORT = 45455
private const val MAGIC = "ALSHIHAB3"
private const val DISCOVER = "ALSHIHAB_DISCOVER"
private const val RESPONSE = "ALSHIHAB_HERE"
private const val CHUNK = 256 * 1024
private const val GCM_TAG_BITS = 128

class TransferManager(private val context: Context) {
    data class Device(val id: String, val name: String, val address: String, val port: Int = TRANSFER_PORT)
    data class SelectedFile(val uri: Uri, val name: String, val size: Long)
    data class IncomingFile(val name: String, val size: Long, val sha256: String)
    data class Incoming(val socket: Socket, val files: List<IncomingFile>, val totalBytes: Long, val sender: String)
    data class HistoryItem(val direction: String, val fileCount: Int, val totalBytes: Long, val timestamp: Long, val success: Boolean)
    data class TransferState(
        val active: Boolean = false,
        val direction: String = "",
        val currentFile: String = "",
        val transferred: Long = 0,
        val total: Long = 0,
        val speedBytes: Long = 0,
        val done: Boolean = false,
        val error: String? = null,
        val encrypted: Boolean = true
    )

    @Volatile var localName: String = "هاتف الشهاب"
    val pairingCode: String = deviceId.chunked(2).take(3).joinToString("-") { it.uppercase() }
    @Volatile var devices: List<Device> = emptyList(); private set
    @Volatile var incoming: Incoming? = null; private set
    @Volatile var state: TransferState = TransferState(); private set
    @Volatile var history: List<HistoryItem> = emptyList(); private set
    @Volatile private var activeSocket: Socket? = null
    private val prefs: SharedPreferences = context.getSharedPreferences("shihab_history", Context.MODE_PRIVATE)

    private val main = android.os.Handler(context.mainLooper)
    private val deviceId = UUID.randomUUID().toString().take(8)
    private val deviceListeners = CopyOnWriteArrayList<(List<Device>) -> Unit>()
    private val stateListeners = CopyOnWriteArrayList<(TransferState) -> Unit>()
    private val incomingListeners = CopyOnWriteArrayList<(Incoming?) -> Unit>()
    private var server: ServerSocket? = null
    private var discoverySocket: DatagramSocket? = null
    private var discoveryThread: Thread? = null
    private var serverThread: Thread? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val partsDir = File(context.cacheDir, "shihab_parts").apply { mkdirs() }

    internal fun contextForPrivate() = context
    fun onDevices(listener: (List<Device>) -> Unit) { deviceListeners += listener; listener(devices) }
    fun onState(listener: (TransferState) -> Unit) { stateListeners += listener; listener(state) }
    fun onIncoming(listener: (Incoming?) -> Unit) { incomingListeners += listener; listener(incoming) }

    fun start() {
        loadHistory()
        try {
            val wifi = context.applicationContext.getSystemService(WifiManager::class.java)
            multicastLock = wifi?.createMulticastLock("shihab-discovery")?.apply { setReferenceCounted(true); acquire() }
        } catch (_: Exception) {}
        startServer(); startDiscovery()
    }
    fun stop() {
        try { discoverySocket?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        discoveryThread?.interrupt(); serverThread?.interrupt()
        try { multicastLock?.release() } catch (_: Exception) {}
        multicastLock = null
    }
    fun refresh() { Thread { broadcastDiscovery() }.start() }
    fun cancelTransfer() { try { activeSocket?.close() } catch (_: Exception) {} }
    fun clearHistory() { history = emptyList(); prefs.edit().clear().apply() }

    private fun startServer() {
        if (server != null) return
        serverThread = Thread {
            try {
                server = ServerSocket(TRANSFER_PORT)
                while (!Thread.currentThread().isInterrupted) {
                    val socket = server!!.accept()
                    Thread { inspectIncoming(socket) }.start()
                }
            } catch (_: Exception) {}
        }.apply { name = "ShihabTransferServer"; start() }
    }

    private fun startDiscovery() {
        if (discoveryThread != null) return
        discoveryThread = Thread {
            try {
                discoverySocket = DatagramSocket(DISCOVERY_PORT).apply { broadcast = true; soTimeout = 1200 }
                while (!Thread.currentThread().isInterrupted) {
                    broadcastDiscovery()
                    val end = System.currentTimeMillis() + 900
                    while (System.currentTimeMillis() < end) {
                        try {
                            val buf = ByteArray(512); val packet = DatagramPacket(buf, buf.size)
                            discoverySocket!!.receive(packet)
                            val text = String(packet.data, 0, packet.length)
                            val p = text.split('|')
                            if (text.startsWith(RESPONSE) && p.size >= 4 && p[1] != deviceId) {
                                updateDevices(Device(p[1], p[2], packet.address.hostAddress ?: return@Thread, p[3].toIntOrNull() ?: TRANSFER_PORT))
                            } else if (text.startsWith(DISCOVER) && p.size >= 3 && p[1] != deviceId) sendResponse(packet.address)
                        } catch (_: SocketTimeoutException) {}
                    }
                    pruneDevices()
                }
            } catch (_: Exception) {}
        }.apply { name = "ShihabDiscovery"; start() }
    }

    private fun broadcastDiscovery() {
        try {
            val socket = discoverySocket ?: DatagramSocket().also { it.broadcast = true }
            val data = "$DISCOVER|$deviceId|$localName".toByteArray()
            socket.send(DatagramPacket(data, data.size, InetAddress.getByName("255.255.255.255"), DISCOVERY_PORT))
            if (socket !== discoverySocket) socket.close()
        } catch (_: Exception) {}
    }
    private fun sendResponse(address: InetAddress) {
        try {
            val socket = discoverySocket ?: return
            val data = "$RESPONSE|$deviceId|$localName|$TRANSFER_PORT".toByteArray()
            socket.send(DatagramPacket(data, data.size, address, DISCOVERY_PORT))
        } catch (_: Exception) {}
    }

    private val seen = HashMap<String, Long>()
    private fun updateDevices(device: Device) {
        synchronized(seen) { seen[device.id] = System.currentTimeMillis() }
        val list = synchronized(seen) {
            seen.keys.mapNotNull { id -> if (id == device.id) device else devices.find { it.id == id } }.distinctBy { it.id }
        }
        postDevices(list)
    }
    private fun pruneDevices() {
        val now = System.currentTimeMillis()
        val list = synchronized(seen) { seen.entries.removeIf { now - it.value > 4500 }; devices.filter { seen.containsKey(it.id) } }
        postDevices(list)
    }
    private fun postDevices(list: List<Device>) { devices = list; main.post { deviceListeners.forEach { it(list) } } }

    fun send(files: List<SelectedFile>, device: Device) {
        if (files.isEmpty()) return
        Thread {
            var socket: Socket? = null
            try {
                socket = Socket(device.address, device.port).apply {
                    activeSocket = this
                    tcpNoDelay = true; sendBufferSize = 1024 * 1024; receiveBufferSize = 1024 * 1024
                }
                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 1024 * 1024))
                val input = DataInputStream(BufferedInputStream(socket.getInputStream(), 128 * 1024))
                val keyPair = createKeyPair()
                val metadata = files.map { SelectedMeta(it, sha256Uri(it.uri, it.size)) }
                val total = metadata.sumOf { max(0L, it.file.size) }
                output.writeUTF(MAGIC); output.writeUTF(localName); output.writeInt(metadata.size)
                metadata.forEach { output.writeUTF(it.file.name); output.writeLong(it.file.size); output.writeUTF(it.sha256) }
                writeBytes(output, keyPair.public.encoded); output.flush()

                val accepted = input.readByte().toInt() == 1
                if (!accepted) throw IllegalStateException("رفض المستلم عملية الاستقبال")
                val receiverPublic = readBytes(input)
                val key = deriveKey(keyPair, decodePublic(receiverPublic))
                val offsets = LongArray(metadata.size) { input.readLong().coerceAtLeast(0L) }

                var totalSent = offsets.sum()
                metadata.forEachIndexed { index, meta ->
                    if (offsets[index] > meta.file.size) throw IllegalStateException("بيانات الاستكمال غير صالحة")
                    postState(TransferState(true, "إرسال", meta.file.name, totalSent, total, 0, false, true))
                    sendFile(meta.file, offsets[index], output, key) { delta, speed ->
                        totalSent += delta
                        postState(TransferState(true, "إرسال", meta.file.name, totalSent, total, speed, false, true))
                    }
                }
                output.flush()
                postState(TransferState(false, "إرسال", "اكتمل الإرسال — مشفّر", total, total, 0, true, null, true))
                addHistory(HistoryItem("إرسال", files.size, total, System.currentTimeMillis(), true))
            } catch (e: Exception) {
                postState(TransferState(false, "إرسال", "", 0, 0, 0, false, e.message ?: "انقطع الاتصال. يمكن إعادة الإرسال للاستكمال", true))
                addHistory(HistoryItem("إرسال", files.size, total, System.currentTimeMillis(), false))
            } finally { try { socket?.close() } catch (_: Exception) {}; activeSocket = null }
        }.start()
    }

    private data class SelectedMeta(val file: SelectedFile, val sha256: String)

    private fun sendFile(file: SelectedFile, offset: Long, output: DataOutputStream, key: ByteArray, onProgress: (Long, Long) -> Unit) {
        context.contentResolver.openInputStream(file.uri)?.use { raw ->
            BufferedInputStream(raw, 1024 * 1024).use { input ->
                var skipped = 0L
                while (skipped < offset) {
                    val n = input.skip(offset - skipped)
                    if (n <= 0) throw IllegalStateException("تعذر الوصول إلى نقطة الاستكمال")
                    skipped += n
                }
                val buffer = ByteArray(CHUNK)
                var remaining = file.size - offset
                var sentForSpeed = 0L; var lastTime = System.nanoTime()
                while (remaining > 0) {
                    val plainLen = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                    if (plainLen <= 0) throw IllegalStateException("تعذر قراءة ${file.name}")
                    val nonce = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, nonce))
                    val encrypted = cipher.doFinal(buffer, 0, plainLen)
                    output.writeInt(plainLen); output.writeInt(encrypted.size); output.write(nonce); output.write(encrypted)
                    remaining -= plainLen; sentForSpeed += plainLen
                    val now = System.nanoTime()
                    if (now - lastTime >= 250_000_000L) {
                        onProgress(sentForSpeed, sentForSpeed * 1_000_000_000L / (now - lastTime)); sentForSpeed = 0; lastTime = now
                    } else onProgress(plainLen.toLong(), 0)
                }
            }
        } ?: throw IllegalStateException("تعذر فتح الملف: ${file.name}")
    }

    private fun inspectIncoming(socket: Socket) {
        try {
            socket.tcpNoDelay = true; socket.soTimeout = 30_000
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), 1024 * 1024))
            if (input.readUTF() != MAGIC) { socket.close(); return }
            val sender = input.readUTF()
            val count = input.readInt().coerceIn(1, 500)
            val files = ArrayList<IncomingFile>(count)
            repeat(count) { files += IncomingFile(input.readUTF(), input.readLong().coerceAtLeast(0L), input.readUTF()) }
            val senderPublic = readBytes(input)
            val inc = Incoming(socket, files, files.sumOf { it.size }, sender)
            incoming = inc
            pendingSenderKeys[socket] = decodePublic(senderPublic)
            main.post { incomingListeners.forEach { it(inc) } }
        } catch (_: Exception) { try { socket.close() } catch (_: Exception) {} }
    }

    private val pendingSenderKeys = java.util.Collections.synchronizedMap(java.util.WeakHashMap<Socket, PublicKey>())

    fun acceptIncoming() {
        val inc = incoming ?: return
        incoming = null; main.post { incomingListeners.forEach { it(null) } }
        Thread {
            try {
                val socket = inc.socket; activeSocket = socket; socket.soTimeout = 0
                val senderPublic = pendingSenderKeys.remove(socket) ?: throw IllegalStateException("جلسة غير صالحة")
                val keyPair = createKeyPair(); val key = deriveKey(keyPair, senderPublic)
                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 128 * 1024))
                val offsets = inc.files.map { existingOffset(it) }
                output.writeByte(1); writeBytes(output, keyPair.public.encoded); offsets.forEach(output::writeLong); output.flush()
                val input = DataInputStream(BufferedInputStream(socket.getInputStream(), 1024 * 1024))
                var totalReceived = offsets.sum()
                inc.files.forEachIndexed { index, file ->
                    val start = offsets[index]
                    postState(TransferState(true, "استقبال", file.name, totalReceived, inc.totalBytes, 0, false, true))
                    receiveFile(input, file, start, key) { delta, speed ->
                        totalReceived += delta
                        postState(TransferState(true, "استقبال", file.name, totalReceived, inc.totalBytes, speed, false, true))
                    }
                }
                postState(TransferState(false, "استقبال", "اكتمل الاستقبال — تم التحقق", inc.totalBytes, inc.totalBytes, 0, true, null, true))
                addHistory(HistoryItem("استقبال", inc.files.size, inc.totalBytes, System.currentTimeMillis(), true))
                socket.close()
            } catch (e: Exception) {
                postState(TransferState(false, "استقبال", "", 0, inc.totalBytes, 0, false, e.message ?: "انقطع الاتصال؛ يمكن إعادة المحاولة للاستكمال", true))
                addHistory(HistoryItem("استقبال", inc.files.size, inc.totalBytes, System.currentTimeMillis(), false))
                try { inc.socket.close() } catch (_: Exception) {}
            } finally { activeSocket = null }
        }.start()
    }

    fun rejectIncoming() {
        val inc = incoming ?: return
        incoming = null
        Thread {
            try { DataOutputStream(inc.socket.getOutputStream()).apply { writeByte(0); flush() }; inc.socket.close() } catch (_: Exception) {}
            pendingSenderKeys.remove(inc.socket); main.post { incomingListeners.forEach { it(null) } }
        }.start()
    }

    private fun existingOffset(file: IncomingFile): Long {
        val f = partFile(file.sha256)
        return if (f.exists()) f.length().coerceAtMost(file.size) else 0L
    }

    private fun receiveFile(input: DataInputStream, file: IncomingFile, offset: Long, key: ByteArray, onProgress: (Long, Long) -> Unit) {
        val part = partFile(file.sha256)
        if (!part.parentFile.exists()) part.parentFile.mkdirs()
        val output = FileOutputStream(part, true).buffered(CHUNK)
        output.use { out ->
            var received = offset; var speedBytes = 0L; var lastTime = System.nanoTime(); var lastBytes = received
            while (received < file.size) {
                val plainLen = input.readInt()
                val encryptedLen = input.readInt()
                if (plainLen !in 1..CHUNK || encryptedLen !in (plainLen + 16)..(plainLen + 32)) throw IllegalStateException("حزمة نقل غير صالحة")
                val nonce = ByteArray(12); input.readFully(nonce)
                val encrypted = ByteArray(encryptedLen); input.readFully(encrypted)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, nonce))
                val plain = cipher.doFinal(encrypted)
                if (plain.size != plainLen || received + plain.size > file.size) throw IllegalStateException("حجم بيانات غير صحيح")
                out.write(plain); received += plain.size
                val now = System.nanoTime()
                if (now - lastTime >= 250_000_000L) {
                    speedBytes = (received - lastBytes) * 1_000_000_000L / (now - lastTime); lastBytes = received; lastTime = now
                }
                onProgress(plain.size.toLong(), speedBytes)
            }
            out.flush()
        }
        if (sha256File(part) != file.sha256) throw IllegalStateException("فشل التحقق من سلامة الملف: ${file.name}")
        finalizePart(part, file.name)
    }

    private fun finalizePart(part: File, name: String) {
        val safeName = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "ملف" }
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, safeName); put(MediaStore.Downloads.MIME_TYPE, guessMime(safeName)); put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/الشهاب")
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("تعذر إنشاء ملف الاستقبال")
            try {
                resolver.openOutputStream(uri, "w")?.use { out -> part.inputStream().use { it.copyTo(out, 1024 * 1024) } } ?: throw IllegalStateException("تعذر فتح ملف الاستقبال")
                part.delete()
            } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "الشهاب"); if (!dir.exists()) dir.mkdirs()
            val target = uniqueFile(dir, safeName); part.copyTo(target, overwrite = false); part.delete()
        }
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name); if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name); val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        var i = 1; while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }; return f
    }

    private fun partFile(hash: String) = File(partsDir, "$hash.part")

    private fun createKeyPair(): KeyPair = KeyPairGenerator.getInstance("EC").apply { initialize(256) }.generateKeyPair()
    private fun decodePublic(encoded: ByteArray): PublicKey = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(encoded))
    private fun deriveKey(local: KeyPair, remote: PublicKey): ByteArray {
        val agreement = KeyAgreement.getInstance("ECDH"); agreement.init(local.private); agreement.doPhase(remote, true)
        val secret = agreement.generateSecret(); val digest = MessageDigest.getInstance("SHA-256"); return digest.digest(secret)
    }

    private fun sha256Uri(uri: Uri, size: Long): String {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val md = MessageDigest.getInstance("SHA-256"); val buffer = ByteArray(1024 * 1024); var remaining = size
            while (remaining > 0) { val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt()); if (n <= 0) break; md.update(buffer, 0, n); remaining -= n }
            return md.digest().toHex()
        } ?: throw IllegalStateException("تعذر قراءة الملف للتحقق")
    }
    private fun sha256File(file: File): String = file.inputStream().use { input -> MessageDigest.getInstance("SHA-256").digestStream(input).toHex() }

    private fun writeBytes(out: DataOutputStream, bytes: ByteArray) { out.writeInt(bytes.size); out.write(bytes) }
    private fun readBytes(input: DataInputStream): ByteArray { val n = input.readInt(); if (n !in 1..4096) throw IllegalStateException("مفتاح غير صالح"); return ByteArray(n).also(input::readFully) }
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it.toInt() and 0xff) }
    private fun MessageDigest.digestStream(input: java.io.InputStream): ByteArray { val b = ByteArray(1024 * 1024); while (true) { val n = input.read(b); if (n < 0) break; update(b, 0, n) }; return digest() }

    private fun guessMime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"; "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "mov" -> "video/quicktime"; "mp3" -> "audio/mpeg"; "pdf" -> "application/pdf"; "zip" -> "application/zip"; "apk" -> "application/vnd.android.package-archive"; else -> "application/octet-stream"
    }


    private fun loadHistory() {
        val raw = prefs.getString("items", "") ?: ""
        history = raw.split("\n").filter { it.isNotBlank() }.mapNotNull { row ->
            val p = row.split("|")
            if (p.size != 5) null else HistoryItem(p[0], p[1].toIntOrNull() ?: 0, p[2].toLongOrNull() ?: 0L, p[3].toLongOrNull() ?: 0L, p[4] == "1")
        }.take(50)
    }

    private fun addHistory(item: HistoryItem) {
        history = (listOf(item) + history).take(50)
        prefs.edit().putString("items", history.joinToString("\n") { "${it.direction}|${it.fileCount}|${it.totalBytes}|${it.timestamp}|${if (it.success) 1 else 0}" }).apply()
    }

    private fun postState(value: TransferState) { state = value; main.post { stateListeners.forEach { it(value) } } }
}
