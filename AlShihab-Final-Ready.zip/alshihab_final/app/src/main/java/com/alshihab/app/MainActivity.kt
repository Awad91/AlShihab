package com.alshihab.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Navy = Color(0xFF061226)
private val Card = Color(0xFF102447)
private val Blue = Color(0xFF168BFF)
private val Cyan = Color(0xFF28D7FF)

class MainActivity : ComponentActivity() {
    private lateinit var manager: TransferManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = TransferManager(this)
        if (Build.VERSION.SDK_INT <= 28 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 44)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), 45)
        } else if (Build.VERSION.SDK_INT in 31..32 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 46)
        }
        setContent { AlShihabApp(manager) }
    }
    override fun onDestroy() { manager.stop(); super.onDestroy() }
}

@Composable
fun AlShihabApp(manager: TransferManager) {
    var tab by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("home") }
    var selectedUris by remember { mutableStateOf(listOf<TransferManager.SelectedFile>()) }
    var devices by remember { mutableStateOf(manager.devices) }
    var transfer by remember { mutableStateOf(manager.state) }
    var incoming by remember { mutableStateOf(manager.incoming) }
    var incomingSender by remember { mutableStateOf("") }
    DisposableEffect(manager) {
        val dl: (List<TransferManager.Device>) -> Unit = { devices = it }
        val sl: (TransferManager.TransferState) -> Unit = { transfer = it }
        val il: (TransferManager.Incoming?) -> Unit = { incoming = it }
        manager.onDevices(dl); manager.onState(sl); manager.onIncoming(il); manager.start()
        onDispose { }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, secondary = Cyan, background = Navy)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            when (screen) {
                "home" -> HomeScreen(onSend = { screen = "send" }, onReceive = { screen = "receive" }, onHistory = { screen = "history" })
                "send" -> SendScreen(manager, selectedUris, { selectedUris = it }, { screen = "home" }, { screen = "devices" })
                "devices" -> DeviceScreen(manager, devices, transfer, { screen = "send" }, { d -> manager.send(selectedUris, d); screen = "progress" })
                "progress" -> ProgressScreen(manager, transfer) { screen = "home" }
                "history" -> HistoryScreen(manager, manager.history) { screen = "home" }
                "receive" -> ReceiveScreen(manager, transfer, incoming) { screen = "home" }
                "settings" -> SettingsScreen { screen = "home" }
            }
        }
    }
    if (incoming != null) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("طلب استقبال ملفات") },
            text = { Text("جهاز آخر يريد إرسال ${incoming!!.files.size} ملف إليك بإجمالي ${formatBytes(incoming!!.totalBytes)}. هل تريد الاستقبال؟") },
            confirmButton = { Button(onClick = { manager.acceptIncoming() }) { Text("قبول") } },
            dismissButton = { OutlinedButton(onClick = { manager.rejectIncoming() }) { Text("رفض") } }
        )
    }
}

@Composable fun AppHeader(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        Spacer(Modifier.weight(1f)); Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable fun HomeScreen(onSend: () -> Unit, onReceive: () -> Unit, onHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("الشهاب", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text("نقل ملفاتك بسرعة وأمان", color = Color.LightGray)
        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().height(250.dp).background(Brush.verticalGradient(listOf(Color(0xFF0B2B5A), Color(0xFF08162D))), RoundedCornerShape(30.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Bolt, null, tint = Cyan, modifier = Modifier.size(72.dp)); Text("الشهاب", fontSize = 42.sp, fontWeight = FontWeight.ExtraBold); Text("شارك الصور والفيديوهات والملفات عبر Wi‑Fi", color = Color.LightGray) }
        }
        Spacer(Modifier.height(22.dp)); ActionButton("إرسال ملف", Icons.Default.Upload, onSend); Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) { Text("سجل النقل") }
        OutlinedButton(onClick = onReceive, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(10.dp)); Text("استقبال ملف", fontSize = 17.sp) }
        Spacer(Modifier.weight(1f)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Feature(Icons.Default.Bolt, "سريع جداً"); Feature(Icons.Default.Wifi, "بدون إنترنت"); Feature(Icons.Default.Security, "آمن وموثوق") }
    }
}
@Composable fun Feature(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Cyan); Text(text, fontSize = 12.sp, color = Color.LightGray) } }
@Composable fun ActionButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) { Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Icon(icon, null); Spacer(Modifier.width(10.dp)); Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold) } }
@Composable fun CardBox(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) { Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(34.dp)); Spacer(Modifier.width(14.dp)); Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, color = Color.LightGray, fontSize = 13.sp) } } }

@Composable
fun SendScreen(manager: TransferManager, selected: List<TransferManager.SelectedFile>, onSelected: (List<TransferManager.SelectedFile>) -> Unit, onBack: () -> Unit, next: () -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val files = uris.map { uri ->
            val name = queryName(manager, uri); val size = querySize(manager, uri); TransferManager.SelectedFile(uri, name, size)
        }
        onSelected(files)
    }
    Column(Modifier.fillMaxSize()) {
        AppHeader("إرسال الملفات", onBack); Column(Modifier.padding(20.dp)) {
            CardBox("متصل بشبكة Wi‑Fi", "اكتشاف الأجهزة القريبة يعمل تلقائياً", Icons.Default.Wifi); Spacer(Modifier.height(18.dp))
            ActionButton("اختيار الصور والفيديوهات والملفات", Icons.Default.FolderOpen) { picker.launch(arrayOf("*/*")) }
            Spacer(Modifier.height(16.dp)); Text(if (selected.isEmpty()) "لم يتم اختيار ملفات" else "تم اختيار ${selected.size} ملفات — ${formatBytes(selected.sumOf { it.size })}", color = Color.LightGray)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) { items(selected) { FileRow("${it.name}  •  ${formatBytes(it.size)}") } }
            if (selected.isNotEmpty()) ActionButton("اختيار الجهاز للإرسال", Icons.Default.Send, next)
        }
    }
}

@Composable
fun DeviceScreen(manager: TransferManager, devices: List<TransferManager.Device>, transfer: TransferManager.TransferState, onBack: () -> Unit, onChoose: (TransferManager.Device) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        AppHeader("الأجهزة القريبة", onBack); Column(Modifier.padding(20.dp)) {
            CardBox("اكتشاف تلقائي", if (devices.isEmpty()) "ابحث عن أجهزة الشهاب على نفس Wi‑Fi" else "تم العثور على ${devices.size} جهاز", Icons.Default.Wifi)
            Spacer(Modifier.height(14.dp))
            Button(onClick = { manager.refresh() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("تحديث الأجهزة") }
            Spacer(Modifier.height(14.dp))
            if (devices.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Wifi, null, tint = Cyan, modifier = Modifier.size(64.dp)); Text("لا توجد أجهزة حالياً", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("تأكد من اتصال الهاتفين بنفس شبكة Wi‑Fi", color = Color.LightGray) } }
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(devices) { d -> DeviceRow(d) { onChoose(d) } } }
        }
    }
}

@Composable fun DeviceRow(device: TransferManager.Device, onClick: () -> Unit) { Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Smartphone, null, tint = Cyan, modifier = Modifier.size(40.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(device.name, fontWeight = FontWeight.Bold); Text(device.address, color = Color.LightGray, fontSize = 12.sp) }; Button(onClick = onClick, shape = RoundedCornerShape(12.dp)) { Text("إرسال") } } }

@Composable fun ProgressScreen(manager: TransferManager, state: TransferManager.TransferState, onDone: () -> Unit) {
    val fraction = if (state.total > 0) (state.transferred.toFloat() / state.total).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AppHeader(if (state.direction == "استقبال") "جاري الاستقبال" else "جاري الإرسال")
        Spacer(Modifier.height(50.dp)); Box(contentAlignment = Alignment.Center) { CircularProgressIndicator(progress = { fraction }, modifier = Modifier.size(180.dp), strokeWidth = 14.dp); Text("${(fraction * 100).toInt()}%", fontSize = 34.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(28.dp)); Text(state.currentFile.ifBlank { "في انتظار البدء" }, fontWeight = FontWeight.Bold); Text("${formatBytes(state.transferred)} / ${formatBytes(state.total)}", color = Color.LightGray); Spacer(Modifier.height(10.dp)); Text(if (state.speedBytes > 0) "السرعة: ${formatBytes(state.speedBytes)}/ث" else "", color = Cyan)
        Spacer(Modifier.weight(1f)); if (state.active) { OutlinedButton(onClick = { manager.cancelTransfer() }, modifier = Modifier.fillMaxWidth()) { Text("إلغاء النقل") }; Spacer(Modifier.height(12.dp)) }; if (state.done || state.error != null) { if (state.error != null) Text(state.error!!, color = Color(0xFFFF8A80)); Spacer(Modifier.height(12.dp)); ActionButton("العودة للرئيسية", Icons.Default.Home, onDone) }
    }
}

@Composable fun ReceiveScreen(manager: TransferManager, transfer: TransferManager.TransferState, incoming: TransferManager.Incoming?, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) { AppHeader("استقبال الملفات", onBack); Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Spacer(Modifier.height(60.dp)); Icon(Icons.Default.Wifi, null, tint = Cyan, modifier = Modifier.size(100.dp)); Spacer(Modifier.height(20.dp)); Text(if (transfer.active) "جاري الاستقبال…" else "بانتظار اتصال جهاز آخر", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("أرسل من هاتف آخر يعمل عليه الشهاب ومتصل بنفس شبكة Wi‑Fi", color = Color.LightGray, modifier = Modifier.padding(20.dp)); if (transfer.active) { Spacer(Modifier.height(30.dp)); Text("${formatBytes(transfer.transferred)} / ${formatBytes(transfer.total)}"); LinearProgressIndicator(progress = { if (transfer.total > 0) transfer.transferred.toFloat() / transfer.total else 0f }, modifier = Modifier.fillMaxWidth().padding(20.dp)) } } }
}

@Composable
fun HistoryScreen(manager: TransferManager, history: List<TransferManager.HistoryItem>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        AppHeader("سجل النقل", onBack)
        Column(Modifier.padding(20.dp)) {
            if (history.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد عمليات نقل حتى الآن", color = Color.LightGray) }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { manager.clearHistory() }) { Text("مسح السجل") }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(history) { item ->
                        CardBox(
                            if (item.direction == "إرسال") "إرسال • ${item.fileCount} ملفات" else "استقبال • ${item.fileCount} ملفات",
                            "${formatBytes(item.totalBytes)} • ${if (item.success) "اكتملت بنجاح" else "لم تكتمل"}",
                            if (item.success) Icons.Default.CheckCircle else Icons.Default.Error
                        )
                    }
                }
            }
        }
    }
}

@Composable fun SettingsScreen(onBack: () -> Unit) { Column(Modifier.fillMaxSize()) { AppHeader("الإعدادات", onBack); Column(Modifier.padding(20.dp)) { CardBox("الوضع الليلي", "مفعّل", Icons.Default.DarkMode); Spacer(Modifier.height(12.dp)); CardBox("مجلد حفظ الملفات", "Downloads / الشهاب", Icons.Default.Folder); Spacer(Modifier.height(12.dp)); CardBox("أمان الاتصال", "تأكيد الاستقبال قبل النقل", Icons.Default.Security) } } }
@Composable fun FileRow(name: String) { Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(15.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.InsertDriveFile, null, tint = Blue); Spacer(Modifier.width(12.dp)); Text(name, maxLines = 1); Spacer(Modifier.weight(1f)); Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF35D39A)) } }

private fun queryName(manager: TransferManager, uri: Uri): String { return manager.javaClass.let { try { manager.contextForPrivate().contentResolver.query(uri, arrayOf("_display_name"), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: (uri.lastPathSegment ?: "ملف") } catch (_: Exception) { uri.lastPathSegment ?: "ملف" } } }
private fun querySize(manager: TransferManager, uri: Uri): Long { return try { manager.contextForPrivate().contentResolver.query(uri, arrayOf("_size"), null, null, null)?.use { c -> if (c.moveToFirst()) c.getLong(0) else 0L } ?: 0L } catch (_: Exception) { 0L } }

private fun formatBytes(bytes: Long): String { if (bytes < 1024) return "$bytes B"; val units = arrayOf("KB", "MB", "GB", "TB"); var v = bytes.toDouble(); var i = -1; do { v /= 1024; i++ } while (v >= 1024 && i < units.lastIndex); return String.format(Locale.US, "%.1f %s", v, units[i]) }
